# PubMed API Wrapper for python
Pubmed documentation is less than ideal. Making this library to  help python researchers easily query PubMed.
